
//Declaración de clases
public class Auto {
    //Los sustantivos con las Clases, los verbos son los Métodos
    //y los adjetivos son Atributos
    
    //Atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    //Metodo constructor
    Auto(){} //constructor vacío
    Auto (String marca, String modelo, String color){
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
    }

    //Métodos
    void acelerar(){ //void= función incrustada dentro de la clase;
        velocidad+=10;
        if(velocidad>100) velocidad=100;        //regla de negocio
    }

    //Sobrecarga de métodos
    //Métodos con parámetros de entrada
    void acelerar(int kilometros){
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }


        void frenar(){
        velocidad-=10;
    }

    //Método con devolución de valor
    int obtenerVelocidad(){
        return velocidad;
    }

    //Método toString()
    @Override
    public String toString(){
        return marca+", "+modelo+", "+color;
    }

    //la clase es una generalidad, que representa después a cada objeto
    //la clase no representa a la instancia

} //end class
